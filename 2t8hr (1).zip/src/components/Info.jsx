import React from "react";

function Info() {
  return (
    <div className="note">
      <h1>Javscript and React .js Bootcamp</h1>
      <p>
        *ONLY THE FINAL REGISTERED STUDENTS WILL BE ELEIGIBLE FOR THE CERTIFICATION ON COMPLETION OF THE BOOTCAMP*
      </p>
    </div>
  );
}

export default Info;
