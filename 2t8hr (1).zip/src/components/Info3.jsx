import React from "react";

function Info3() {
  return (
    <div className="note">
      <h1>FULL STACK WEBDEVELOPMENT</h1>
      <p>
      *ONLY THE FINAL REGISTERED STUDENTS WILL BE ELEIGIBLE FOR THE CERTIFICATION ON COMPLETION OF THE BOOTCAMP
      </p>
    </div>
  );
}

export default Info3;