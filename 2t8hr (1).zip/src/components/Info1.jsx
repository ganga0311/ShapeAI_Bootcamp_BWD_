import React from "react";

function Info1() {
  return (
    <div className="note">
      <h1>Python and cybersecurity Bootcamp</h1>
      <p>
      *ONLY THE FINAL REGISTERED STUDENTS WILL BE ELEIGIBLE FOR THE CERTIFICATION ON COMPLETION OF THE BOOTCAMP*.
      </p>
    </div>
  );
}

export default Info1;
